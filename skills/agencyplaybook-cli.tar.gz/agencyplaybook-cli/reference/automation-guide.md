# AgencyPlaybook CLI Automation Guide

`apb` is the AgencyPlaybook command-line tool — an operator-grade command layer for agencies that need safe execution, reporting, diagnostics, playbooks, and controlled campaign operations against the Meta Marketing API.

This guide covers **unattended execution**: CI/CD pipelines, cron jobs, AI-agent workflows (Claude Code, Codex, etc.), and shell scripts. For interactive use, run `apb --help` and explore subcommands directly.

> **Tenant disable propagation:** When an admin disables a tenant via `/admin/tenants`, the CLI begins returning `403 tenant_inactive` within **30 seconds** (the local `~/.apb/tenant_context.json` cache TTL).
>
> **Account selection (CI/agents):** in unattended runs, set the target account explicitly — `--account act_…` per command, or `META_AD_ACCOUNT_ID` in the job's environment/`.env`. As of **v0.2.1**, `META_AD_ACCOUNT_ID` **takes precedence over** any persisted `~/.apb/config.json` `default_account` left on the runner, so a stale global default can't silently redirect a job to the wrong account. `apb` echoes `[apb] account: … (source: …)` to stderr for the audit trail. For interactive/multi-account operators, `apb account use <profile>` (after `apb account profile add … --token-env VAR`) switches the account **and** its token together; CI/agents should still pin `--account` / `META_AD_ACCOUNT_ID` explicitly rather than rely on a persisted active profile.

---

## Machine-Safe Execution

Three flags govern every unattended invocation. Combine them as needed.

| Flag | Effect |
|---|---|
| `--no-input` | Promise that the CLI will never prompt. Any future prompt callsite returns a `safety_gate_blocked` error instead of reading stdin. |
| `--json` | Output structured JSON instead of human-readable tables. Errors emit a structured envelope (see below). |
| `--execute` | Apply changes. Required for all mutations. Without it, the CLI runs in dry-run mode and emits a `would_create` / `would_update` envelope. |
| `--confirm-destructive` | Required in addition to `--execute` for `DELETE`, `ARCHIVE`, $0 budget, and >200% budget changes. |

Read-only commands need none of these (other than optional `--json`):

```bash
apb account list --json
apb report insights --account act_123 --days 30 --json
apb playbook fatigue-index --account act_123 --json
```

Mutations always require `--execute` (without it the CLI dry-runs and exits 0); destructive ones additionally require `--confirm-destructive` (omitting it is a validation error, exit 2):

```bash
apb campaign update-status --id @spring-sale --status PAUSED --execute --json
apb campaign delete --id @old-test --execute --confirm-destructive --json
```

**`--no-input` does not bypass any safety gate.** If a write needs `--execute`, `--no-input` does not supply it; the command simply **dry-runs and exits 0** (it does not mutate). The flag's only job is to forbid stdin reads — see *Safety Model* below.

---

## Pagination & pre-emptive throttling (large accounts)

**Avoid silent truncation.** For the high-volume list reads — `campaign list`, `adset list`, `ad list`, `creative list`, `audience list` — `--limit` is the **page size**, not a total cap. A bare `list` returns only the first page, so an agent iterating an account with more rows than `--limit` will silently miss the rest. Two flags close this (july2-platform-polish-001 A3.2):

| Flag | Effect |
|---|---|
| `--all` | Follow `paging.cursors.after` until the account is fully drained and return the complete set. **Use this in agent loops** so you never truncate. |
| `--after <cursor>` | Fetch exactly one page starting from a `paging.cursors.after` cursor (manual paging / resuming). |

```bash
apb ad list --all --status ACTIVE --json        # complete active-ad set, no truncation
apb audience list --all --json
```

In `--json` mode the output stays a stable bare array (no envelope change); the "next page" cursor hint is human-mode only. `catalog products` keeps its own single-page `--after`; `leadgen leads-export` has its own follow-loop.

**Pre-emptive throttle is ON by default** (july2-platform-polish-001 A3.1): a large `--all` sweep automatically pre-sleeps when Meta's rolling usage crosses the soft/hard thresholds (60/80%), so agent loops don't walk into a 429 cascade. It only ever *delays* — it never fails a correct request. Opt out for max-speed scripts with `APB_NO_THROTTLE=1` (the legacy `APB_THROTTLE=0` also disables it).

---

## Exit Codes

Every failure maps to a documented exit code. Scripts and CI runners can branch on these without parsing stderr:

| Code | Meaning | Examples |
|---:|---|---|
| `0` | Success | command completed; dry-run rendered |
| `1` | General / unmapped | I/O error, config parse failure, fall-through |
| `2` | Validation / invalid input | clap parse error, missing required flag, malformed JSON, invalid `--url` |
| `3` | Auth / permission | invalid `APB_API_KEY`, expired token, unauthorized account, missing scope, tier upgrade required |
| `4` | Safety gate blocked | `--execute` provided on a mutation but env-gates (`READ_ONLY` / `ALLOW_WRITES` / `APB_ALLOW_MUTATIONS`) blocked the write (`write_blocked`); a guardrail profile blocked the write (`guardrail_blocked` — see [Agency guardrails](#agency-guardrails-local-write-mistake-prevention)); or `--no-input` blocked a would-prompt path (`safety_gate_blocked`). **Without `--execute` the CLI dry-runs and exits 0; a missing `--confirm-destructive` is exit 2 (validation), not 4.** |
| `5` | Network / rate-limit / 5xx | Meta API timeout, 429 throttle, 5xx response, connection refused |
| `6` | Partial success | reserved for future batch operations |

When `--json` is set on a failing command, stdout emits a structured envelope. Stderr is empty.

```json
{
  "ok": false,
  "error": {
    "code": "write_blocked",
    "message": "Write blocked: READ_ONLY != false",
    "exit_code": 4,
    "details": {
      "reasons": ["READ_ONLY != false", "ALLOW_WRITES != true"]
    }
  }
}
```

Per-class `error.details` payloads:

| Variant | `error.code` | `details` |
|---|---|---|
| Write blocked | `write_blocked` | `reasons: [string]` — env-var and flag gate failures |
| Safety gate blocked | `safety_gate_blocked` | `gate: string`, `required_flags: [string]` |
| Guardrail blocked | `guardrail_blocked` | `account: string`, `violations: [{code, message, allow_flag, subject}]`, `allow_flags: [string]` |
| Insufficient scope | `insufficient_scope` | `required_scope`, `current_tier`, `minimum_tier` |
| Account not authorized | `account_not_authorized` | `account_id` |
| Rate limited | `rate_limited` | `retry_after_ms` |

Errors **not** in this table (e.g. `validation_error`, `auth_error`) emit a flat envelope — `code` + `message` + `exit_code`, with no `details` object.

---

## Agency guardrails (local write mistake-prevention)

The `apb` CLI enforces an optional per-account **guardrail profile** on write commands —
risk-proportional mistake-prevention for unattended / agent execution (wrong landing
domain, off-brand copy, over-cap budget). It is local and honor-based; the adversarial
boundary (scope / tier / account access) stays server-side. With no profile configured,
nothing is enforced (backward compatible).

**Control model** — precedence, highest first:

1. `--guardrails on|warn|off` flag (per-command).
2. `APB_GUARDRAIL_*` environment variables — ideal for CI:
   - `APB_GUARDRAIL_ALLOWED_DOMAINS` (comma-separated hosts)
   - `APB_GUARDRAIL_CANONICAL_BRANDS` (comma-separated)
   - `APB_GUARDRAIL_BLOCKED_TERMS` (comma-separated)
   - `APB_GUARDRAIL_MAX_DAILY_BUDGET` (major currency units, e.g. `500`)
   - `APB_GUARDRAIL_ENFORCEMENT` = `block` (default) | `warn` | `off`
3. The stored profile at `~/.apb/guardrails.json` (`apb guardrails set …`).

**Enforcement** fires on a real write (`--execute`) to `creative create-*`,
`adset create` / `update-budget`, and `campaign create` / `update` / `compose-from-spec`:

- `block` → the write is refused with **exit code 4** (`guardrail_blocked`) *before any
  Meta call*. The `--json` envelope carries the `violations[]` and the `allow_flags[]`
  that would waive them.
- `warn` → violations print to stderr; the write proceeds (exit follows the write).
- `off` → no enforcement.

**Overrides** (each writes an audit line to `logs/apb.jsonl`): `--allow-domain <host>`
(repeatable), `--allow-brand`, `--allow-budget` — all require `--guardrail-reason "<why>"`.
A missing reason on an override is `validation_error` (exit 2).

```bash
# Fail-closed CI: enforce a budget ceiling + domain allowlist via env, no stored profile.
export APB_GUARDRAIL_ALLOWED_DOMAINS="client.com"
export APB_GUARDRAIL_MAX_DAILY_BUDGET="500"
export APB_GUARDRAIL_ENFORCEMENT="block"
apb adset create --account act_123 --campaign 456 --name "CI adset" \
  --daily-budget 9000 --execute --json
# → exit 4, error.code = guardrail_blocked (budget_over_cap)

# Preview-only (no API call, never errors) — useful as a CI lint step:
apb guardrails test --account act_123 --link https://wrong.com/lp --budget 9000 --json
```

---

## Ergonomic creative builders + leadgen ad-create (v0.2.0)

Sprint 3 of agency-gaps-v2 added 7 new `apb` commands paired with 7 API endpoints — operator-friendly builders that generate v25 `AdCreative` JSON internally. CI patterns:

- `apb creative create-image-simple` / `create-video-simple` — single-asset creatives. Image/video flags accept local paths (auto-upload under `--execute`) or Meta hashes/IDs.
- `apb creative create-lead-form-ad` — injects `lead_gen_form_id` into `link_data.call_to_action.value`. Validates form exists pre-write.
- `apb creative create-catalog-creative --format <single|carousel|collection|automatic>` — auto-wires the matching Sprint-1 `--allow-*` flag from the `--format` intent. Operators don't need to manually pass `--allow-collection` for a `--format collection` creative.
- `apb creative create-story-template` / `create-reels-video-template` — emit `story_advisories` / `reels_advisories` arrays (9:16 reminder, safe-zone, video length limits).
- `apb leadgen ad-create` — end-to-end orchestrator. Validates campaign objective is `OUTCOME_LEADS` + form belongs to page BEFORE any write. Reverse-pauses the creative if ad-create fails.

API parity: every CLI command has a paired `POST /api/v1/creatives/...` (or `/api/v1/leadgen/ad-create`) endpoint accepting the same fields as a typed JSON body. See `rust/docs/API_REFERENCE.md` § v0.2.0 Ergonomic Builders.

## Creative format auditor (v0.2.0, exit 2)

Every creative `create-*` subcommand and `apb creative update` runs a pure-function auditor on the spec before any write. Detects 11 unintended Meta v25 format-expansion variants (CAROUSEL / COLLECTION / FORMAT_AUTOMATION / `product_set_id` / `template_url` / `{{product.*}}` / etc. — the Scandalous Coffee class).

For CI / unattended pipelines:
- `--strict-format` upgrades dry-run findings to exit 2 (fail loud on any finding). Use this in pre-merge checks.
- `--audit-only` runs the auditor and exits 0 without writing, regardless of `--execute`. Use for spec-review jobs that want to read the `format_audit.findings` array via `--json`.
- When `--execute` is set and the audit detects unwhitelisted findings, the binary exits 2 BEFORE the write gate's exit 4 — so CI scripts that branch on exit code see the actionable auditor message, not the env complaint.
- Whitelist matching findings explicitly with `--allow-carousel`, `--allow-collection`, `--allow-automatic-format`, `--allow-format-automation`, `--allow-catalog-template`.

Full risk taxonomy + flag-by-flag reference at [`../rust/docs/CREATIVE_AUDITOR.md`](../rust/docs/CREATIVE_AUDITOR.md).

```yaml
# Example: GitHub Actions step that audits every committed creative spec.
- name: Audit creative specs
  run: |
    for spec in specs/creative/*.json; do
      apb creative create-image --name "ci-$(basename $spec .json)" --spec-file "$spec" --strict-format --json
    done
```

---

## Compose spec v2 — reviewing the compiled payload (`--print-compiled`)

`campaign compose-from-spec` accepts a **v2** spec (`"schema_version": 2`) whose
`targeting_brief` / `creative_brief` / `advantage` / `placements` / `schedule` /
`bidding` blocks the binary compiles into the literal Meta payloads. A v1 spec
(no `schema_version`, or `1`) is unaffected.

For an unattended pipeline the useful property is that the compile step is
**pure** — `--print-compiled` makes no API calls and needs no credentials, so it
runs in the same CI stage as your linters:

```bash
# Fails the job (exit 2) if the brief can't compile, and prints the exact
# targeting / asset_feed_spec a reviewer signs off on.
apb --json campaign compose-from-spec --spec-file brief.json --print-compiled \
  > compiled.json
jq -e '.ad_sets[0].targeting.targeting_automation.advantage_audience != null' compiled.json
jq '.compile_warnings // []' compiled.json
```

| Field in the output | Use |
|---|---|
| `ad_sets[].targeting` | the literal Meta targeting spec that will be POSTed |
| `ad_sets[].ads[].creative` | `{"type":"asset_feed", …}` when it came from a `creative_brief` |
| `compile_warnings[]` | `placement_removed_in_v26` · `unresolved_reference` · `creative_format_risk` · `ai_disclosure_not_sent` |

Exit codes are the usual ones: a fail-loud conflict (both `targeting` and
`targeting_brief`, both `creative` and `creative_brief`, a missing `advantage`
block under v2) is `validation_error` → **exit 2**, before any network call.

Under `--execute` the run adds the v2 stages — `audiences → lead_forms →
campaign → per ad set → rules` — and the failure envelope grows
`created_before_failure.{audience_ids,lead_form_ids,rule_ids}` plus
`rollback.{deleted,not_reversible}`. **`not_reversible` needs a human**: Meta has
no DELETE for a lead-gen form, so a rolled-back run can leave one behind.

## Pre-flight Guards (`validation_error`, exit 2, during `--dry-run`)

A growing set of Meta-side rejections are now caught **before any network call** — so they fail fast on `--dry-run`, not after `--execute`. All return exit `2` with `error.code = "validation_error"`. Agents can either branch on the exit code (already covered) or pattern-match the message excerpt.

| Guard | Trigger | Message excerpt | Since |
|---|---|---|---|
| **Objective must be ODAX** | `campaign create` / `campaign compose-from-spec` with a non-`OUTCOME_*` objective (legacy `CONVERSIONS`, `LINK_CLICKS`, `POST_ENGAGEMENT`, …) | `objective 'CONVERSIONS' is not a valid Meta v25 objective … (CONVERSIONS → OUTCOME_SALES)` | v0.1.19 |
| **Conversion goal needs `promoted_object`** | `adset create` / compose with `--optimization-goal OFFSITE_CONVERSIONS` or `VALUE` and no `--promoted-object` | `optimization-goal OFFSITE_CONVERSIONS … requires a promoted_object — pass --promoted-object '{"pixel_id":"<id>","custom_event_type":"PURCHASE"}'` | v0.1.19 |
| **Dayparting needs a lifetime budget** | `--daypart-hours` / `--adset-schedule` + `--daily-budget` on create; or `adset update --adset-schedule` against a daily-budget ad set (or its CBO parent campaign — the CLI fetches both) | `adset_schedule (dayparting) requires a lifetime budget; daily-budget ad sets can't use fixed daypart scheduling` | v0.1.15 (create) / v0.1.17 (update + CBO parent) |
| **Dayparting windows must fit the flight** | Any `timezone_type=ADVERTISER` window's recurring slot never intersects `start_time → end_time` (e.g. lifetime $350 with windows past `--end-time …T10:00`). Skipped for flights ≥ 7 days. | `N daypart window(s) fall entirely outside the flight (… .. …) and will never deliver: HH:MM-HH:MM, …` | v0.1.20 |
| **Placement preset conflict** | `--placements <preset>` on `adset create` / `adset update-targeting` when the operator's `--targeting` JSON already contains `publisher_platforms` / `facebook_positions` / `instagram_positions` | `--placements reels conflicts with --targeting.publisher_platforms (operator set X, preset wants Y). Remove one of them.` | v0.2.0 |

All guards are deterministic and best-effort: `USER`-timezone windows, parse failures on times, and lookup failures (e.g. parent campaign GET errors) **pass through** rather than block — Meta stays the final authority. No false positives by design.

### Soft `advisories[]` (non-blocking, v0.1.20)

The `adset create` / `adset update` result includes an `advisories[]` string array (top-level, alongside `id` or inside the dry-run envelope) for Meta-accepted setups that usually under-deliver:

| Trigger | Sample message |
|---|---|
| Lifetime budget, flight < 24h | `Flight is only Xh — a lifetime budget paces poorly over <1 day; use a daily budget or a longer flight.` |
| Lifetime budget, flight < 6 days | `Flight is ~Xd — Meta typically needs ≥6 days to exit the learning phase; short flights can under-deliver.` |
| Lifetime / dayparted ad set with no `end_time` | `Lifetime budget / dayparting requires --end-time …` |

Agents should surface advisories to the operator but **not** treat them as failures. The exit code stays `0` (dry-run) or `0` (execute success); `advisories` is omitted when empty.

### Full-body dry-run preview (v0.1.20)

`adset create --dry-run` returns a `would_create` object that contains the **complete** request body Meta would receive: `campaign_id`, `name`, `optimization_goal`, `billing_event`, `targeting` (with `targeting_automation.advantage_audience` injected), `daily_budget` / `lifetime_budget`, `bid_strategy`, `bid_amount`, `pacing_type`, `promoted_object`, `start_time`, `end_time`, `adset_schedule`, `status`. (`adset update` previews the full `changes` map.) Agents can verify budget/conversion/schedule wiring without `--execute`.

```json
{
  "ok": true,
  "dry_run": true,
  "would_create": {
    "campaign_id": "120…",
    "name": "Evening Sales",
    "optimization_goal": "OFFSITE_CONVERSIONS",
    "billing_event": "IMPRESSIONS",
    "lifetime_budget": "35000",
    "pacing_type": ["day_parting"],
    "promoted_object": {"pixel_id": "…", "custom_event_type": "ADD_TO_CART"},
    "adset_schedule": [/* 6 windows */],
    "start_time": "2026-06-01T00:00:00-0700",
    "end_time": "2026-06-08T23:59:00-0700",
    "status": "PAUSED",
    "targeting": {/* … */}
  },
  "advisories": [],
  "blocked_reasons": ["--execute flag not provided", "READ_ONLY != false", …]
}
```

---

## CI/CD Examples

### Read-only health check (GitHub Actions, GitLab, etc.)

```bash
apb doctor check --no-input --json
# exit 0 = healthy; non-zero = config drift or expired credentials
```

### Daily insights pull

```bash
apb report insights \
  --account act_123 \
  --days 7 \
  --no-input --json \
  > reports/$(date -I).json
```

### Dry-run a campaign change before merging

```bash
apb campaign update \
  --id @spring-sale \
  --account act_123 \
  --daily-budget 5000 \
  --no-input --json
# Without --execute the CLI prints a dry-run envelope ({"dry_run": true,
# "changes": {...}, "blocked_reasons": [...]}) and exits 0.
# Use this in PR previews so reviewers can see the projected change.
```

### Plan it, don't do it (`--plan`) — a reviewable artifact for approval gates

`--plan <path>` runs the full dry-run pipeline and writes a human plan document
(`<path>.md`) plus a re-playable, SHA-256-hashed machine plan (`<path>.json`) —
zero API mutation. It is the offline analogue of the MCP preview→approve→execute
handshake: an agent (or CI job) emits the plan, a human reviews the `.md`, and the
`.json` is applied later via the `plan apply --from-file` subcommand. Cannot be
combined with `--execute` (hard error).

```bash
# A budget change, captured as a plan a reviewer can approve — no write.
apb adset update-budget \
  --id @spring-adset \
  --daily-budget 50 \
  --account act_123 \
  --no-input --plan artifacts/scale.md
# Writes artifacts/scale.md + artifacts/scale.md.json, exits 0, mutates nothing.
# stderr: "apb: --plan wrote machine plan (1 action(s)) → artifacts/scale.md.json"

# A diagnostic playbook, converted into a proposed change set:
apb playbook waste-audit --account act_123 --no-input --plan artifacts/waste.md
# rebalance / waste-audit / fatigue-index derive actions from findings;
# other playbooks write the doc with a "not yet plannable" section (no JSON twin).
```

Coverage: the mutation cohort (`campaign update-status|duplicate|delete`,
`adset update-budget|update-targeting|delete`, `ad update-status|create|delete`,
`creative create-image|create-video`), **`campaign compose-from-spec`** (a whole
campaign build — see below), and the `rebalance` / `waste-audit` /
`fatigue-index` playbooks emit machine plans. Other mutating commands run a normal
dry-run and note `not yet plannable`; pure reads note `nothing to plan`. The plan
file carries no authority — apb's full 5-layer write gate + SaaS write-policy/scope
are re-enforced at apply time.

### Build a whole campaign from a brief (`recipe build`)

`apb recipe build --brief brief.yaml --out DIR` is the plan-first entry point for
a *new* campaign: it compiles the brief to a compose spec v2, runs the compile
pre-flight, and writes `spec.v2.json` + `plan.json` (a plan-envelope-v2 create
plan) + `plan.md` + `plan.html` + `summary.json`. Dry-run by default; exit 2 on a
brief the compiler refuses (unknown objective, no budget, `provider: agent` with
no copy, a `channel: google` brief).

```bash
apb recipe build --brief brief.yaml --out build/ --format all --no-input
# CI gate: fail the job if the plan carries any warning
python3 -c "import json,sys; sys.exit(1 if json.load(open('build/summary.json'))['warnings'] else 0)"

# apply later, through the same executor an imported plan uses
apb plan apply --from-file build/plan.json                       # preview
READ_ONLY=false ALLOW_WRITES=true APB_ALLOW_MUTATIONS=true \
  apb plan apply --from-file build/plan.json --execute            # born PAUSED
```

`apb plan get --id <plan_id> --format v2` prints a stored plan's envelope (the
same document `GET /api/v1/plans/:id` returns under `data.envelope`), and
`apb plan export --from-file <plan.json> --format html [--fonts web]` re-renders
any envelope as the shareable review page. `apb context init|show` keeps the
per-account goal/brand document those recipes read — local state, no Graph call.

### Apply a plan from a file (`plan apply --from-file`)

Apply the `.json` twin back through the plan framework. Dry-run by default
(import + validate + preview, zero mutation); `--execute` plus the four env/CLI
write gates applies it. Exit codes follow the standard table (`0` dry-run OK,
`4` write-blocked-with-`--execute`, `2` validation error for a tampered/stale
file without its override).

```bash
# Preview in CI — imports + validates, sends nothing, exit 0
apb plan apply --from-file artifacts/scale.md.json --no-input --json

# Apply in a gated deploy step
APB_ALLOW_MUTATIONS=true ALLOW_WRITES=true READ_ONLY=false \
  apb plan apply --from-file artifacts/scale.md.json --execute --no-input --json
```

The plan file is untrusted input. `plan apply` re-checks the integrity **hash**
(a hand-edited file is refused unless `--allow-edited-plan`) and re-reads recorded
prior values for a **staleness** check (a drifted file is refused unless
`--allow-stale-plan`); delete-class / blast-radius-5 actions additionally require
`--confirm-destructive`. A gads plan file, or one from a newer apb, is rejected.
`plan export --id <plan-id> --out <path>` serializes a stored plan back to a
portable file that round-trips through `plan apply`. HTTP parity:
`POST /api/v1/plans/import` (import + validate only; execution stays on
`POST /api/v1/plans/:id/execute[-safe]`).

#### Whole-build plans (`compose-from-spec --plan`) — the unattended shape

A compose plan is the one case where the artifact contains a dependency chain, so
an agent driving it needs three extra fields.

```bash
# 1. Plan (no mutation, no approval needed to produce it)
apb campaign compose-from-spec --spec-file brief.json --no-input --plan artifacts/build.json
jq -r '.actions[] | "\(.id) \(.op)"' artifacts/build.json
# a1 campaign.create / a2 adset.create / a3 creative.create / a4 ad.create

# 2. Apply behind the gate; capture the receipt
APB_ALLOW_MUTATIONS=true ALLOW_WRITES=true READ_ONLY=false \
  apb plan apply --from-file artifacts/build.json --execute --no-input --json > receipt.json

# 3. Branch on the outcome — NOT on the exit code alone
case "$(jq -r .status receipt.json)" in
  EXECUTED) echo "build complete" ;;
  PARTIAL)  echo "stopped after $(jq -r .completed_through receipt.json) — rolling back"
            jq .rollback_envelope receipt.json > rollback.json
            APB_ALLOW_MUTATIONS=true ALLOW_WRITES=true READ_ONLY=false \
              apb plan apply --from-file rollback.json --execute --confirm-destructive --no-input --json ;;
  FAILED)   echo "nothing was created"; exit 1 ;;
esac
```

- `status` — `EXECUTED` (all actions landed) / `PARTIAL` (some did; entities exist) /
  `FAILED` (none did). A partial build is a normal outcome, not a crash: on the Meta
  sandbox the creative layer is blocked by a Page permission, so a full build stops
  after the ad set.
- `completed_through` — the id of the last action that succeeded.
- `rollback_envelope` — a ready-to-apply plan that deletes exactly what was created,
  children first. It is all delete-class, so applying it needs `--confirm-destructive`.

Actions reference each other with `{{ref:aN}}` (the ad set's `campaign_id` is
`{{ref:a1}}`) and address the account as `{{account}}/campaigns`. Both are bound at
apply time — never edit them by hand, and never assume the ids exist before the
apply runs. `source.context_snapshot` carries the typed `CampaignComposeSpec`, so an
agent can re-derive or diff the build from the plan file alone.

### Merging plans and the `wait-for-status` gate (`plan merge`)

`plan merge` (planning-001 sprint-m03) is a pure local transform — no write
gates needed, no API call unless it reads a live ad-set's learning status
(skip that too with `--offline`). It combines N plan files, isolates any
contradictory bidding/targeting/budget change as an unresolved `conflict`,
and — for anything gated behind Meta's Smart-Bidding learning window —
inserts a `wait-for-status` step that `plan apply` (and the read-only `plan
validate --from-file`) evaluate against the live status every time they run.
An agent driving this in CI never needs to poll separately: a skipped action
is reported, never treated as a failure, and never blocks the rest of the
plan.

```bash
apb plan merge --from build/plan.json --from fatigue.json \
  --out merged.json --no-input --json
# {"waves": [...], "conflicts": [...], "action_count": N, ...}

# Read-only: is anything still waiting?
apb plan validate --from-file merged.json --no-input --json > check.json
jq -r '.status' check.json                 # "imported" | "waiting-on-learning"

APB_ALLOW_MUTATIONS=true ALLOW_WRITES=true READ_ONLY=false \
  apb plan apply --from-file merged.json --execute --no-input --json > receipt.json
jq -r '.waiting[]?.wait_id, .expired[]?.wait_id' receipt.json
# non-empty ⇒ re-run this SAME file later; skipped actions are still pending,
# not failed — receipt.json's exit code is 0 either way.
```

`conflicts[]` in the merged JSON are never auto-resolved — a human (or a
downstream review step) picks one side and re-emits that action before the
next merge.

### Weekly portfolio rebalance (`agency portfolio plan`, planning-001 S4)

`agency portfolio plan` never calls the SaaS API and never mutates the
account by itself — it's a local, read-only allocator that only ever writes
plan files. Safe to run unattended on a schedule; the produced plan still
needs `plan apply --execute` (with the usual write gates) to take effect.

```bash
apb agency portfolio plan --accounts act_123456789 \
  --max-step-pct 10 --out portfolio.plan.json --no-input --json
jq '.moves | length, .note' portfolio.plan.json
# N   null           <- moves proposed, or
# 0   "no ad set..." <- empty-but-correct (e.g. a zero-spend account)

# Review, then apply like any other plan-envelope-v2 document
APB_ALLOW_MUTATIONS=true ALLOW_WRITES=true READ_ONLY=false \
  apb plan apply --from-file portfolio.plan.json --execute --no-input --json
```

See `rust/docs/planning.md` § "portfolio plan" for the method (marginal
return from 30d/60d slopes, learning + ROAS-floor + headroom gates) and the
`--meta-portfolio-out` cross-channel bridge schema.

### Gated mutation in a deployment job

```bash
set -e
apb campaign update-status \
  --id @spring-sale \
  --status PAUSED \
  --account act_123 \
  --no-input --json --execute
case $? in
  0) echo "paused" ;;
  4) echo "FAILED: missing safety flag — should not happen with --execute"; exit 1 ;;
  5) echo "TRANSIENT: network/5xx — retry with backoff"; exit 75 ;;
  *) echo "FATAL: $?"; exit 1 ;;
esac
```

### Destructive op with explicit confirmation

```bash
apb campaign delete \
  --id @old-test \
  --account act_123 \
  --no-input --json --execute --confirm-destructive
```

---

## AI Agent / Claude Usage

Recommended invocation pattern for an agent (Claude Code, Codex, etc.) running `apb` programmatically:

1. **Always pass `--no-input --json`.** Promise no prompts; consume structured JSON.
2. **Never pass `--execute` without explicit user authorization for that specific command.** A user saying "yes proceed" once is not blanket authorization for future invocations — re-confirm per command.
3. **Branch on `error.exit_code`, not `error.message`** — messages are localized and may evolve; codes are stable contract.
4. **For destructive operations**, surface the dry-run output to the user before the `--execute --confirm-destructive` invocation. Never auto-confirm.

Minimal Claude-style invocation:

```bash
apb playbook fatigue-index \
  --account act_123 \
  --no-input --json
```

Decision tree on the result:
- `exit 0` → parse `data` and act on findings
- `exit 4` → safety gate blocked; report `error.details.required_flags` to user, do not proceed
- `exit 3` → auth issue; ask user to refresh credentials
- `exit 5` → transient; back off and retry up to N times
- `exit 2` → user-input bug; surface `error.message` to user, do not retry

---

## Debugging

`--debug` installs `tracing_subscriber` with **stderr** output and sets `RUST_LOG=apb_cli=debug,apb_core=debug,apb_api=debug` if the env var is unset. JSON output on stdout is unaffected.

The CLI emits debug events from three targets out of the box:

| Target | Where | Sample fields |
|---|---|---|
| `apb_cli::dispatch` | top of every command dispatch | `execute`, `dry_run`, `confirm_destructive`, `json_output`, `no_input`, `tenant_authenticated` |
| `apb_core::http` | every Meta Graph API call (request entry, success, error) | `method`, `endpoint`, `status`, `latency_ms`, `attempt`, `retryable`, `param_keys` |
| `apb_core::gate` | every write-gate evaluation, both dry-run and exit-4 paths | `execute_attempted`, `allowed`, `reasons` |

Sample `--debug` stderr from a list call:

```text
DEBUG apb_cli::dispatch: dispatch start execute=false dry_run=false json_output=true no_input=true tenant_authenticated=true
DEBUG apb_core::http:    graph request method="GET" endpoint=act_X/campaigns param_keys=["fields", "limit"]
DEBUG apb_core::http:    graph response ok endpoint=act_X/campaigns status=200 latency_ms=750 attempt=0
```

**Explicit `RUST_LOG` always wins** over the `--debug` default — narrow or widen the filter as needed:

```bash
# Narrow to one target
RUST_LOG=apb_core::http=debug apb --debug campaign list

# Widen to include third-party HTTP plumbing (reqwest, hyper)
RUST_LOG=apb_cli=debug,apb_core=debug,reqwest=debug,hyper_util::client=info apb --debug campaign list

# Maximum verbosity (TLS handshakes, pool checkouts, etc.)
RUST_LOG=trace apb --debug campaign list
```

For per-command structured audit events (always on, independent of `--debug`), tail the JSONL file:

```bash
tail -f logs/apb.jsonl                  # all events
jq 'select(.event=="campaign.update")' < logs/apb.jsonl
```

### Sanitization

`apb_core::log_sanitize::redact()` runs on events flowing through the apb logger and tracing layer. **Third-party events surfaced via a widened `RUST_LOG` (reqwest, hyper) bypass the apb sanitizer** — choose your filter accordingly when piping to a log aggregator. Patterns the sanitizer covers:

- `Authorization: Bearer <token>` → `Bearer [REDACTED]`
- `?access_token=<value>` and `?refresh_token=<value>` → `<param>=[REDACTED]`
- `apb_live_<tier>_<32+ hex>` and `apb_test_<tier>_<32+ hex>` → `apb_<env>_[REDACTED]`
- `EAA<long base64-ish>` (Meta system-user / page tokens) → `EAA[REDACTED]`

The CLI writes structured JSONL events to `logs/apb.jsonl` regardless of `--debug` — that is the canonical apb event stream today.

---

## Plain Output / Log Aggregation

ANSI escape sequences interfere with log aggregators (CloudWatch, Datadog, Loki, Splunk). The CLI honors three opt-out signals:

| Signal | Source |
|---|---|
| `--no-color` | CLI flag (highest priority) |
| `NO_COLOR=1` | environment variable (de-facto standard) |
| `CLICOLOR=0` | environment variable (BSD ls convention) |

Any of the three forces clap's color choice to `Never`. JSON output is ANSI-free regardless.

```bash
NO_COLOR=1 apb campaign list --account act_123 | tee /var/log/apb.log
```

---

## Dynamic Creative Quick Experiments

For production DCO use, author an `asset_feed_spec` JSON file and pass it via `--spec-file`. For quick experiments and ad-hoc testing, the CLI accepts inline flags:

```bash
apb creative create-dynamic \
  --name "DCO Test - May" \
  --image abc123def456 \
  --image fedcba654321 \
  --title "Lower Your Monthly Payment" \
  --title "Compare Loan Options Fast" \
  --body "Check your options without hurting your credit." \
  --body "See personalized offers in minutes." \
  --cta LEARN_MORE \
  --url https://example.com \
  --account act_123 \
  --page-id 1234567890 \
  --dry-run --json
```

### Image input modes

`--image` accepts either a Meta image hash or a local file path:

- **Hash** (e.g. `abc123def456`): used directly. No upload happens.
- **Path** (starts with `./`, `/`, `~/`, `..`, or ends with `.jpg|.jpeg|.png|.gif|.webp`): the CLI calls `apb_core::services::creative::upload_image()` to mint a hash, then assembles the spec.
  - Under `--execute`, this is a real upload.
  - Under `--dry-run`, no upload happens; the spec is stamped with `<dry_run_placeholder:./img.jpg>` so you can inspect the planned shape. To verify the upload itself before a dry-run, use `apb creative upload-image --path ./img.jpg --execute` first to mint the hash, then pass the hash inline.

To disambiguate an image hash that happens to look like a filename, prefix with `./` to force path mode.

### Conflict rule

`--spec-file` (or `--spec`) and inline DCO flags are **mutually exclusive**:

```bash
apb creative create-dynamic --spec-file dco.json --image abc123 \
  # → exits 2 with: Cannot use --spec-file together with inline DCO flags. Use one input mode.
```

### Inline-mode validators

The CLI rejects inline invocations missing any of:

- ≥1 `--image` (hash or path)
- ≥1 `--title`
- ≥1 `--body`
- `--cta`
- `--url` (parsed as a URL)

Each violation produces an exit-2 `Validation error` naming the missing field.

---

## `--extra-fields` escape hatch (campaign / adset create)

When Meta ships a field `apb` doesn't expose as a flag yet, `--extra-fields '<json-object>'` shallow-merges arbitrary keys into the create body so you don't have to wait for a release:

```bash
apb campaign create --name Q3 --objective OUTCOME_SALES \
  --extra-fields '{"is_skadnetwork_attribution": true}' --dry-run --json
```

Contract for agents/CI:
- **Bypasses apb validation** — the injected keys are sent to Meta as-is. The dry-run preview lists them in `advisories` ("…bypass apb validation…"); surface that to the operator.
- **Fails loud on collision** — if a key duplicates one apb already manages (e.g. `objective`), the command exits 2 with `--extra-fields key '…' collides …`. Use the dedicated flag instead. This means `--extra-fields` can never silently override a validated field.
- Must be a JSON **object** (not an array/scalar) or it exits 2.
- Always preview with `--dry-run` first; the merged body appears under `would_create`.

---

## Safety Model for Unattended Execution

The CLI's safety contract is layered. Each layer must explicitly permit before a mutation runs.

1. **`--no-input`** promises *no prompts*. It does **not** imply approval. Mutations still need `--execute`. This separation is deliberate: an agent or cron job committing to non-interactive execution must still prove it's authorized to write.
2. **Env-var gates** (`READ_ONLY=false`, `ALLOW_WRITES=true`, `APB_ALLOW_MUTATIONS=true`) — three independent operator-controlled toggles.
3. **`--execute`** — explicit per-invocation flag.
4. **`--confirm-destructive`** — required for DELETE / ARCHIVE / $0 budget / >200% budget moves.

Env-gate and `--no-input`-prompt failures abort with **exit 4** — `write_blocked` (`error.details.reasons`) or `safety_gate_blocked` (`error.details.required_flags`). Note the other two layers differ: a missing `--execute` **dry-runs and exits 0** (no abort), and a missing `--confirm-destructive` is a **validation error (exit 2)**.

**`--no-input` never implies approval.** It is a contract between the operator and the CLI that stdin will not be read; nothing more. If you pipe `apb` into a script, you must still satisfy every gate the operation requires. The CLI will refuse rather than guess.

---

## See also

- `reference/exit-codes.md` — canonical exit-code table + agent decision tree (in this skill bundle)
- `reference/scopes.md` — per-scope command list and tier requirements (in this skill bundle)
- Full CLI reference & downloads: <https://agencyplaybook.io> (Developer → CLI Reference) and <https://github.com/affbros/agencyplaybook-cli>
