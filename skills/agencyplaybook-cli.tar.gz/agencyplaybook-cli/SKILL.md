---
name: agencyplaybook-cli
description: |
  AgencyPlaybook CLI (`apb`) — command-line automation for Meta (Facebook/Instagram) ad campaigns: list, create, update, duplicate, and delete campaigns/adsets/ads/creatives; run diagnostic playbooks (health-score, waste-audit, fatigue-index, weekly-digest, learning-accelerator and 20+ more); build and execute multi-entity plans with dry-run-first safety; manage audiences (custom + lookalike + PII upload); explore targeting interests/behaviors; configure pixels and CAPI; manage rules, split-tests, catalogs, custom conversions, and leadgen forms. Covers all 279 commands across 42 domains.

  USE WHEN user says "apb", "agencyplaybook cli", "agencyplaybook", "meta campaign automation", "meta ads via cli", "campaign create", "campaign update", "campaign delete", "duplicate campaign", "scale campaign", "pause campaign", "budget update", "ad set targeting", "creative upload", "audience upload", "lookalike audience", "custom audience", "fatigue check", "waste audit", "health score", "weekly digest", "learning accelerator", "playbook diagnostic", "plan execute", "plan validate", "report insights", "compare periods", "split test", "rules engine", "automation rule", "catalog product set", "custom conversion", "leadgen forms", "pixel health", "CAPI dual signal", "growth score", "retargeting compression", "saturation audit", "broad targeting audit", "no-touch compliance", "consolidation advisor", "ROAS recovery", "anomaly detect", "reset rebuild", "scale roadmap", "rebalance", "daypart audit", "placement audit", "creative mix", "event hierarchy", "duplicate detect", "event downgrade ladder", "andromeda", "dataset clone-plan", "sync diff", "alias create", or otherwise needs to programmatically manage Meta ad accounts via the `apb` CLI.
---

# AgencyPlaybook CLI Skill

This skill packages working knowledge of every `apb` command. Generated on 2026-09-11 from the live binary — 279 commands across 42 domains.

## Routing

- **User asks for a specific command** ("what flags does `apb campaign create` accept?") → open `commands.md` (the domain index), then read `reference/commands/<domain>.md` and quote the relevant section.
- **User asks "how do I X" workflow** ("how do I dry-run-then-execute a campaign?") → read `examples.md` and adapt the matching canonical example.
- **User wants step-by-step onboarding** ("set me up with apb") → read `workflows/setup.md`.
- **User wants automation pattern** ("safe rollout with rollback") → read `workflows/automation.md`.
- **User wants diagnostic playbook** ("which playbook for low ROAS?") → read `workflows/diagnostics.md`.
- **User wants a decision / verdict** ("which campaigns should I scale, tighten, or cap this week?") → read `reference/verdict-framework.md` — collapse the playbook outputs into **one decisive verb per campaign** (SCALE / TIGHTEN / OPTIMIZE / CAP, plus HOLD / CUT) from explicit pass/fail gates, then act on the queue.
- **User manages multiple client accounts** ("set guardrails for this client", "run changes across all my accounts safely", "did I edit the wrong account?") → read `reference/agency-guardrails.md` — the two-dial model (plan for creates/destructive, direct for small edits), the per-write right-account/domain/brand/budget checks, dry-run-all → review-exceptions → execute-clean at scale, and the override/boundary rules.
- **User asks to set up day parting / ad scheduling** ("daypart this campaign", "only run ads 9am–9pm", "schedule ads by hour", "run evenings only") → **the campaign type to create is a NEW campaign/ad set on a LIFETIME budget** (ABO: lifetime on the ad set; CBO: lifetime on the campaign). Day parting is impossible on a **daily** budget and budget *type* can't be converted, so **never try to add it to an existing daily-budget campaign** — build a new one. Read "Meta platform constraints" below + `examples.md` §16 before writing any command.
- **User hits a 403** ("insufficient_scope on X") → read `reference/scopes.md` and explain tier gap.
- **User script needs exit-code branching** → read `reference/exit-codes.md` (the canonical table + decision tree).
- **User wants the full CI/CD + AI-agent automation guide** (debugging, log sanitization, plain output) → read `reference/automation-guide.md`.
- **User asks whether a field can be changed / is updatable / "did that update stick?"** ("can I change a campaign's budget type?", "is `value_rule_set_ids` readable back?", "can I delete a value rule set?") → read `reference/meta-docs-capability-index.json` (what Meta *documents*) **and** `reference/meta-verified-mutability-index.json` (what we *observed*), then answer per the "Capability reasoning" doctrine below. Never answer mutability from memory alone.
- **CLI targets the wrong account, results look stale, or you just connected / switched accounts** ("apb is on the wrong account", "I reconnected Meta", "data doesn't match Ads Manager") → refresh the CLI cache: `apb meta cache --clear` (drops cached responses + post-429 cooldown markers + the cached tenant context under `~/.apb`, forcing a clean token + account re-resolve next run), then verify with `apb account current` and `apb meta status`. This is the first thing to try for any wrong-account / stale-data symptom.

## Quick start (always check this first)

The downloaded `apb` binary already targets `https://api.agencyplaybook.io` — you only supply an API key:

```bash
mkdir -p ~/.apb
echo 'APB_API_KEY=apb_live_<tier>_<32hex>' > ~/.apb/.env   # key from the /api-keys page
apb auth test                                              # smoke test
apb campaign list                                          # first real call
```

> **Reading `auth test`:** treat **`is_valid: true` + a populated `user` and `ad_accounts`** as "connected." `app_id`/`scopes` only appear when app credentials (`META_APP_ID`/`META_APP_SECRET`) are set — Meta's `/debug_token` won't let a token introspect itself, so without app creds those fields are omitted (not an error). On `apb` < 0.5.10 this case wrongly showed `is_valid: false` — ignore that if `user`/`ad_accounts` are present, and upgrade. See `workflows/setup.md`.

`apb` resolves credentials in order: shell environment → project-local `.env` (cwd) → `~/.apb/.env` (global) → compile-time default. Earlier sources win, so a `export APB_API_KEY=...` always overrides the file. Setting `~/.apb/.env` once makes the CLI work from any directory. You only need `APB_API_URL` if you're pointing at a non-default endpoint (self-hosting, staging, or local dev — see below).

## Safety doctrine (apply to every mutation)

1. **Dry-run first.** Every write command requires `--execute`. Without it, the CLI prints what it would do and exits 0 without mutating.
2. **Destructive ops also require `--confirm-destructive`.** This covers `delete`, status changes to DELETED/ARCHIVED, budget reductions to $0, budget increases >200%.
3. **Branch on exit code, not on stdout text.** Exit codes are stable; messages are not. See `reference/exit-codes.md`.
4. **Use `--no-input` for CI/CD and AI-agent execution.** Combine with `--json` for machine-parseable output.
5. **Never `--no-input --execute` a destructive op without `--confirm-destructive` already in the command line.** The CLI will refuse to proceed.
6. **Plans over ad-hoc writes.** For anything spanning 2+ entities, use `apb plan create … validate … execute` so the rollback blueprint exists on disk.

## Capability reasoning (documented → attemptable → verified)

Meta's docs and a `200`/exit-0 are **not** proof a field is live-mutable. Some documented-updatable fields are silently dropped, write-only, or rejected at runtime. Before asserting any field can be changed, layer two reference files — never skip straight to a confident claim:

1. **Layer 1 — `reference/meta-docs-capability-index.json` (what Meta DOCUMENTS).** Join on `(object_name, field)`; it carries `supports_{read,create,update,delete}`, `documented_update_fields[]`, and `documented_warnings[]` for Graph v25.0.
   - `supports_update: true` ⇒ Meta documents it ⇒ **attemptable**, *not proven*.
   - `supports_update: false` ⇒ don't attempt; tell the user it's create-frozen.
   - `"unknown"` / absent ⇒ the scrape couldn't classify it (e.g. truncated page) or it isn't indexed yet ⇒ **attemptable-with-caution**. Say "Meta's docs don't clearly state this — we'd have to test it." Never report `unknown` as supported *or* unsupported. Also weigh `extraction_method`/`extraction_confidence`: a `webfetch_assisted`/`partial` entry is a weaker signal than `deterministic_html`/`high`.
2. **Layer 2 — `reference/meta-verified-mutability-index.json` (what we OBSERVED).** Same join key. `observed_result ∈ {meta_rejected, accepted_unverified, verified_applied, conditional, unknown}`. **Layer 2 OVERRIDES Layer 1 on conflict** — a doc-says-yes field we observed `meta_rejected` (e.g. budget-type conversion) is reported as rejected, citing the `evidence` token. Absence of a Layer-2 entry means *untested*, not "works."
3. **Always surface `documented_warnings[]`** (EU DSA, attribution-window limits, character limits, etc.) before the user runs a write.
4. **Never claim a write persisted from a `200`/exit-0 alone.** Meta accepts some fields without returning them (`accepted_unverified`, e.g. `value_rule_set_ids`). Persistence is proven only by a **readback** — the CLI already does this for ad-set schedules (the `verification` block in the result). When a write target is `accepted_unverified` or `unknown`, run a follow-up `apb <entity> get` and compare the field to the intended value; report `verified` vs "accepted but not confirmable." This *extends* the dry-run-first / exit-code doctrine above — it does not replace it.
5. **Feed observations back.** When you (or the user) empirically confirm a field's behavior, propose appending a Layer-2 record `{object_name, field, observed_result, graph_api_version: "v25.0", evidence}`. Layer 2 is **append-only** — never rewrite or delete prior observations.

`reference/meta-node-manifest.json` maps every apb domain to its Meta node (or marks it apb-internal) so you know whether an object even *has* a Meta reference page to reason about.

## Meta platform constraints (what the CLI catches before Meta does)

The CLI pre-flights a growing set of Meta-side rejections at dry-run. Each guard below runs **before any network call** and exits 2 with an actionable message — so a bad command fails on `--dry-run` rather than after `--execute`:

1. **Objective must be ODAX** (v0.1.19, in `campaign create` and `campaign compose-from-spec`). Legacy values are rejected with the OUTCOME_* mapping (e.g. `CONVERSIONS → OUTCOME_SALES`, `LINK_CLICKS → OUTCOME_TRAFFIC`). The CLI's `--objective` is also a clap enum, so the spec-file / HTTP API paths are the ones this guard defends.
2. **Conversion goal needs `--promoted-object`** (v0.1.19). `adset create` (and compose) with `--optimization-goal OFFSITE_CONVERSIONS` or `VALUE` and no `--promoted-object` errors with a `{"pixel_id":"…","custom_event_type":"PURCHASE"}` hint. Scoped to website-conversion goals — no false positives on LINK_CLICKS / leads / app-promo.
3. **Dayparting requires a lifetime budget** (v0.1.15 create, v0.1.17 update). `--daypart-hours` / `--adset-schedule` + `--daily-budget` is rejected on create; on update, the CLI fetches the existing ad set (and its CBO parent campaign) and errors if either is on a daily budget. **Budget type is frozen at create — you cannot convert daily ⇄ lifetime — so the fix is always "create a new entity."**
4. **Dayparting windows must fit the flight** (v0.1.20). `adset create`/`update` rejects daypart windows (ADVERTISER timezone) whose recurring slot never intersects `start_time`→`end_time`, naming the dead windows. Catches the "lifetime budget over a too-short flight" class (e.g. $350 over 10 hours leaves 3 windows that can't deliver). USER-tz windows and ≥7-day flights pass through (no false positives).

The create/update result also carries a soft **`advisories[]`** array (v0.1.20, non-blocking) for Meta-accepted setups that usually under-deliver: flight < 24h, flight < 6 days (Meta needs ~6 days to exit the learning phase), or a lifetime / dayparted ad set with no `--end-time`. Surface these to the user; don't block on them. The dry-run preview's `would_create` (v0.1.20) shows the **full** request body — budget, targeting, `promoted_object`, `pacing_type`, schedule, flight — so the wiring can be verified before `--execute`.

5. **Creative format auditor** (v0.2.0). Every `creative create-*` and `creative update` runs a pure-function auditor on the spec. Detects 11 v25 format-expansion risks (CAROUSEL / COLLECTION / FORMAT_AUTOMATION / product_set_id / template_url / {{product.*}} syntax). When `--execute` is set with unwhitelisted findings, exits 2 with an actionable error naming each detected risk and the `--allow-*` flag that whitelists it — fires BEFORE the env-var write gate so the spec-fix message surfaces first. CI use: `--strict-format` upgrades dry-run findings to errors. Spec-review: `--audit-only` runs the auditor and exits 0 without writing. See `reference/auditor.md` for the full risk taxonomy.

6. **Placement presets** (v0.2.0). `adset create` and `adset update-targeting` accept `--placements <feed|stories|reels|stories-reels|feed-stories-reels|advantage-plus>` — expands into v25 `publisher_platforms` / `facebook_positions` / `instagram_positions`. Merges with operator `--targeting` JSON; **fails loud on conflict** (exit 2, names both sides). IG's feed equivalent is called `stream` in v25 — the preset handles that for you.

7. **Ergonomic creative builders** (v0.2.0). `creative create-image-simple` / `create-video-simple` / `create-lead-form-ad` / `create-catalog-creative` / `create-story-template` / `create-reels-video-template` take operator-friendly flags and build the v25 spec internally — no JSON authoring. `--image` / `--video` / `--thumbnail` accept hashes/IDs OR local file paths (auto-uploaded under `--execute`). `create-catalog-creative --format <single|carousel|collection|automatic>` auto-wires the matching `--allow-*` flag so an intentional `--format collection` doesn't trip the auditor. `creative create-lead-form-ad` injects `lead_gen_form_id` into `link_data.call_to_action.value` — the FIRST occurrence of this field in the codebase.

8. **End-to-end leadgen ad-create** (v0.2.0). `apb leadgen ad-create --campaign --adset --form-id --page-id --image --headline --body --cta` validates the campaign objective is `OUTCOME_LEADS`, verifies the form belongs to the page, creates the lead-form creative + ad in sequence, and reverse-pauses on partial failure. The Page-token check fires FIRST so token failures surface before any creative-write attempt.

9. **Built-in compose presets** (v0.2.0). `apb campaign compose-from-spec --preset <sales-video|sales-carousel|lead-form|catalog-sales|reels-video|stories-video>` produces full campaign + adset + creative + ad stacks from operator-friendly args (`--campaign-name`, `--page-id`, `--daily-budget`, plus per-preset extras). Built-in presets take precedence over user-saved presets; **collision = fail-loud** with a shadowing error (exit 2).

11. **Compose spec v2** (`"schema_version": 2`). `campaign compose-from-spec` accepts brief-shaped blocks (`targeting_brief`, `creative_brief`, `advantage`, `placements`, `schedule`, `bidding`) that the binary compiles into the literal Meta payloads, plus `audiences[]` / `lead_forms[]` pre-stages and a `rules[]` tail. **Always run `--print-compiled` first** — it makes zero API calls and prints the exact `targeting` / `asset_feed_spec` that will be POSTed, plus `compile_warnings[]`. Three things bite: `advantage.audience` (0|1) is **required** in v2 (Meta v26 needs the flag explicit); supplying both a literal and its brief (`targeting`+`targeting_brief`, `creative`+`creative_brief`) is a **fail-loud error, never a merge**; and rollback can **delete** created rules/audiences but a created lead-gen form is **not deletable by API** — it lands in `rollback.not_reversible` for a human. See `examples.md` § 8.

10. **Name uploaded assets** (v0.2.2). Whenever the CLI uploads an image/video from a local file, the asset is named by the file's basename (filename + extension) by default. Override it: `creative upload-image --name`, `creative upload-video --name` (+ `--title` for the display title, which defaults to the name), and per-asset `--image-name` / `--video-name` / `--thumbnail-name` / `--hero-image-name` on the `create-*` builders — distinct from each builder's `--name`, which is the *creative* name. A hash or pre-uploaded ID passed instead of a file path is used as-is.

12. **Plan a whole build, then apply it** (campaign-build-001 M1b). `apb campaign compose-from-spec --spec-file brief.json --plan build.json` writes the build as a plan-envelope-v2 document — ordered `campaign.create` → `adset.create` → `creative.create` → `ad.create` actions, children bound to parents with `{{ref:aN}}` temp references, the account as `{{account}}/campaigns`, and the typed spec preserved in `source.context_snapshot`. Zero mutation. `apb plan apply --from-file build.json --execute` (+ the four write gates) runs it in that atomic order and returns `status` (`EXECUTED`/`PARTIAL`/`FAILED`), `completed_through`, and a `rollback_envelope` that deletes exactly what was created, children first — feed it back through `plan apply --execute --confirm-destructive`. **A create plan needs no `--confirm-destructive`; its rollback always does.** Never hand-edit `{{ref:…}}` / `{{account}}`, and put explicit pixel/page ids in any spec you intend to plan (`"auto"` needs a live lookup a plan can't make — the CLI warns).

13. **Advantage+ switches on a live ad set** (campaign-build-001 M1b). `apb adset update --id <id> --advantage-audience on|off` sets `targeting_automation.advantage_audience`; `--advantage-placements on` applies the `advantage-plus` preset. Both are a read-modify-write over the live targeting, so nothing else is dropped. There is **no `--advantage-placements off`** (manual placements = an explicit set: use `adset update-targeting --placements <preset>`), and neither switch can be combined with the other `adset update` fields in one call — a mixed invocation fails loud naming the clashes.

14. **Merge two plans behind the learning-window guard** (planning-001 sprint-m03). `apb plan merge --from a.json --from b.json --out merged.json [--plan merged.html]` folds N plans into one — dedupes byte-identical actions, isolates a contradictory bidding/targeting/budget change on the same target as an unresolved `conflicts[]` entry (never auto-picked), ranks the rest (`--mode growth|efficiency`), and — for any bidding/targeting-or-optimization-goal/budget change on an ad set whose live `learning_stage_info.status` is `LEARNING` — inserts a `wait-for-status` step ahead of it. `plan apply --from-file merged.json --execute` re-checks that status live and **skips** (never fails, never blocks the rest of the plan) anything still gated; `plan validate --from-file merged.json` is the read-only twin — check `.status` (`"waiting-on-learning"` when everything is still gated) and `.waiting`/`.expired` before applying. `--offline` skips the live status read (conservative: everything gated resolves Unknown, not "clear").

The remaining Meta rejections are account-state rules the CLI can't pre-check (business verification, page permissions, pixel custom-event validity, etc.) — those still bounce on `--execute`.

### Dayparting / ad scheduling → create a LIFETIME-budget campaign

**When day parting is requested, the campaign type to create is a NEW campaign/ad set on a LIFETIME budget.** Choose the structure, then build it fresh:

- **ABO** (budget on the **ad set**) — the usual choice for per-ad-set dayparting: `apb adset create … --lifetime-budget <X> --end-time <T> --daypart-hours "9,12,16,19,21"` (bid strategy also lives on the ad set for ABO). The CLI builds the Meta `adset_schedule` and auto-sets `pacing_type: ["day_parting"]`.
- **CBO / Advantage Campaign Budget** (budget on the **campaign**) — the campaign carries a lifetime budget; the scheduled ad set carries no own budget.

**Do NOT add day parting to an existing campaign unless it is already on a lifetime budget.** Two reasons it can't be retrofitted:

1. A daily budget is rejected outright: **`Campaigns with day parting enabled do not support daily budgets.`**
2. Budget *type* is **frozen at create** — you cannot convert daily ⇄ lifetime: **`Invalid parameter: Changing from lifetime to daily budget or vice versa is not allowed for a campaign.`**

So the only correct move is to **create a new lifetime-budget campaign/ad set from the start** (and pause/retire the old daily-budget one if it's being replaced).

Guards #3 and #4 above (budget-type-vs-schedule + windows-fit-flight) catch both halves at dry-run. The fix is always to **build a new lifetime-budget campaign/ad set with an `--end-time` that covers the schedule** (≥1 week is typical for a dayparted lifetime flight). See `examples.md` §16.

## When to use this skill vs `metaads`

- **`agencyplaybook-cli`** → user wants CLI/script automation, multi-account fan-out, plan/validate/execute safety patterns, exit-code branching, reproducible workflows. Programmatic mindset.
- **`metaads`** → user wants UI-style "publish this campaign" / "what's my ROAS this week" conversational workflows. Doesn't need CLI invocation.

If the user mentions `apb`, scripting, automation, CI/CD, cron, or "rerunning this nightly", route here. If they mention "the dashboard" or just describe a one-off Q&A, route to `metaads`.

## Domain index

See `commands.md` for the domain index; per-command detail lives in `reference/commands/<domain>.md`. Domains:

- **auth, doctor, account, meta** — connection & identity
- **campaign, adset, ad, creative** — entity CRUD
- **audience, targeting, catalog, custom-conversion, leadgen** — supporting primitives
- **report, coverage, metrics, learning** — reporting
- **playbook, growth, action, budget, ask** — diagnostics & recommendations
- **plan** — multi-step mutation orchestration with on-disk rollback blueprints
- **recipe, context** — composed, context-driven operations (`recipe build` = brief → launch-ready campaign) and the per-account goal/brand document they read
- **rules, split-test, sync, duplicate, andromeda, alias** — automation & workflow
- **pixel, dataset, library, search, policy** — utility

## Building a new campaign — always plan first

To build a campaign from a brief, use the **`recipe build`** verb rather than
hand-assembling a compose spec:

```bash
apb recipe describe <name>               # `build` — prints the decision rules; quote them, don't paraphrase
apb recipe build --brief brief.yaml --out build/ --format all
```

It writes `build/{spec.v2.json, plan.json, plan.md, plan.html, preview.html, summary.json}` and
launches nothing. Show the user `plan.html` (or the summary), then either apply
`plan.json` (`apb plan apply --from-file build/plan.json --execute`, four write gates, born
PAUSED) or hand it to AgencyPlaybook for approval (see below). Rollback comes from
`launch.json.rollback_envelope`.

### Handing a plan to AgencyPlaybook, and picking one back up

**CLI → SaaS.** `POST /api/v1/plans/import` with `build/plan.json`'s body imports the envelope as
a row on the tenant's Plans page (`/plans/<id>`) — approve there, or `POST
/plans/:id/approve {mcp_token}` if you're driving it through the MCP handshake, then `POST
/plans/:id/execute` (202, async) and poll `GET /plans/:id` to a terminal state
(`executed`/`failed`). A `failed` run whose receipt created at least one resource is
rollback-eligible: `POST /plans/:id/rollback`. Note `completed_through` before deciding whether to
roll back or build a fresh plan on top.

**SaaS → CLI.** Pull a stored plan back down with `apb plan get --id <id> --format v2 >
plan.json`, then `apb plan validate --from-file plan.json` (dry run) before `apb plan apply
--from-file plan.json --execute`. `apb plan export --from-file plan.json --format html` renders it
for human review outside the SaaS UI. `plan_hash` is re-verified on apply — if you've hand-edited
the file, pass `--allow-edited-plan` and say so explicitly rather than adding it silently.

**`{{ref:aN}}` / `{{account}}`** — a create-class plan addresses entities its own earlier actions
create, so those ids don't exist yet and show up as placeholders. The EXECUTOR (the SaaS job
runner and both CLIs share one ref map per run) binds them at run time. Never hand-edit a ref — it
either fails `unresolved_ref` or silently targets the wrong entity.

Rules to honour when you write a brief:

- `copy.provider: agent` means **you** write the copy into the brief; the binary refuses to
  back-fill it. Empty > inaccurate.
- Every build is born PAUSED; `safety.born_paused: false` is refused.
- Meta has no Ads-Editor export, so a Meta build writes no Editor CSV.
- Per-account goals and brand terms live in `apb context init|show` (a local file, no Graph
  call). A recipe reads it for defaults; it never overrides what the brief states.

## Effective planning

Decision table — pick the smallest tool that gets a real review before anything mutates:

| Situation | Verb | Gate | What the human reviews |
|---|---|---|---|
| One entity, one change | direct mutation, `--execute` | the write gate's own confirm | the dry-run diff |
| ≥2 linked changes (a whole build) | `recipe build` → `plan.json` | `apb plan validate` → approve → `apb plan apply --execute` | `plan.html` / review.html |
| N already-produced plans that might collide, or touch a `LEARNING` target | `apb plan merge` | live learning status clears `wait-for-status` | `conflicts[]`, waves, `.status` |
| "What would this budget/bid change deliver?" | `apb plan forecast` | none — read-only | scenario table (`basis`) |
| Handing the plan to a reviewer / another tool | `POST /api/v1/plans/import`, or the Plans page | `pending → approved` | the Plans page / review.html |
| Undoing a landed change | `apb plan apply --from-file rollback.json --execute --confirm-destructive` | `executed`, or `failed` with a created resource | `launch.json.rollback_envelope` |

Anti-patterns: wrapping a single already-approved status flip in a plan for
ceremony; hand-editing a `{{ref:aN}}` placeholder (fails `unresolved_ref` or
silently targets the wrong entity); replaying a stale plan against a changed
account instead of regenerating it (`apply-plan` refuses on
`plan_envelope_mismatch`); merging without checking `--offline` vs live
learning status. Full doctrine + when-to-merge/forecast: the in-app
**Planning Reference** (`/planning-reference`).

## Tier-aware planning

Before writing a workflow, check the user's tier. Scopes:

- **Starter** (4 scopes): read-only campaigns/reports/coverage/search
- **Professional** (11): + advanced reports, audiences, pixels, core playbooks, catalogs, custom-conversions, leadgen reads
- **Agency** (23): + writes (campaigns/budgets/rules/catalogs/custom-conversions/leadgen/audience-data), full playbooks, datasets, lead PII export
- **Enterprise** (27): + automation, admin sync, split-test, duplicate

If a workflow needs a scope above the user's tier, surface that clearly before writing the command. See `reference/scopes.md` for the full mapping.

## Self-hosting / local development

The default endpoint is `https://api.agencyplaybook.io` — no override needed for the hosted service. Only set `APB_API_URL` when you run the stack yourself:

```bash
# Local dev — Express middleware on :3750. This is the SaaS entry point: it
# resolves your tenant's encrypted Meta token and forwards to the Rust API on
# :3010. Pointing directly at :3010 bypasses Express and silently fails on any
# call that hits Meta's Graph API — always use :3750 for local dev.
export APB_API_URL=http://localhost:3750
```

## Operator token mode (BYO Meta token)

Set `META_OAUTH=DISABLED` **with** a local `META_ACCESS_TOKEN` to bypass the platform's per-tenant Meta OAuth and use your **own** Meta token for every Graph call. Your `APB_API_KEY` is still validated against AgencyPlaybook on every invocation (login + tier/scope + active-user/key enforcement) — only the Meta token is swapped, never the platform gate.

```bash
# ~/.apb/.env  (or a project-local .env)
APB_API_KEY=apb_live_<tier>_<32hex>   # still REQUIRED — access control stays on
META_ACCESS_TOKEN=EAAB...             # your own (System User) Meta token
META_OAUTH=DISABLED
```

When to use it:
- **Self-hosted / single-operator** setups driving one Meta account.
- **Ad creation while the platform's Meta app is in Development Mode** — the platform OAuth token can't create new page-post creatives (`error_subcode 1885183`), but a System User token from your own (non-dev-mode) app can. Existing/deduped creatives may still go through on the platform token; force a unique creative to surface the block.

Rules:
- `META_OAUTH=DISABLED` **without** `APB_API_KEY` is refused — the CLI won't run ungated off a bare local token. Set the key, or unset `META_OAUTH` to use `apb` as a standalone Meta tool.
- The account you target must be reachable by your local token — check with `apb account current` (shows reachability), then switch with `apb account use <profile|act_...>`. For multiple accounts, save profiles that also carry each account's token: `apb account profile add <name> --account act_... --token-env <ENV_VAR>`, then `apb account use <name>` flips account + token together.
- If an admin disables your user/key, the next call is rejected (a ~30s resolve cache applies; `rm ~/.apb/tenant_context.json` to force an immediate re-check).

## Batch scripts (the watchful eye)

A downloadable library of thin bash wrappers around `apb` encodes how a disciplined operator runs an account: **watch constantly, change rarely, no decision without sufficient data.** They are samples users run with their own credentials — the intelligence stays in the binary; each script is auditable in 60 seconds.

Three cadence tiers plus a shared library:

- **Tier 1 — Watchdogs** (daily, strictly read-only): `watch-account-pulse.sh`, `watch-budget-pacing.sh`, `watch-policy-flags.sh`, `watch-tracking-health.sh`, `watch-learning-phase.sh`, `watch-fatigue.sh`, `watch-anomalies.sh`. They observe and alert (exit 10 = attention items) and never propose a change — a daily finding is flagged for the weekly review.
- **Tier 2 — Opportunity scans** (weekly, read-only analysis): `scan-scaling-readiness.sh`, `scan-waste.sh`, `scan-audience-health.sh`, `scan-creative-refresh.sh`, `scan-structure-hygiene.sh`, `scan-query-mining.sh`, plus `check-sufficiency.sh`. Anything actionable renders as a plan document, gated by the data-sufficiency floor and a cooldown check.
- **Tier 3 — Reviews** (weekly/monthly, the only tier that proposes): `weekly-review.sh`, `monthly-strategic-review.sh`, `budget-rebalance.sh`, and `plan-then-apply.sh`.
- **Audit bundles** (`audit-full.sh` + sectioned `audit-*.sh`) run every read-only diagnostic playbook into a timestamped results dir.
- **Shared library** (`lib/common.sh`, `lib/sufficiency.sh`, `lib/cooldown.sh`) and the tunable `thresholds.conf` — defaults mirror the binary's own compiled constants so scripts and playbooks agree on what "enough data" means.

**Safety posture:** shipped scripts **never** write. The single sanctioned write path is `plan-then-apply.sh`, which is interactive — it opens a plan document and makes you type the apply command's confirmation yourself. Every proposed change is a plan document you (or a client) read and approve before anything touches the account.

**Where to get them:** the in-app **Scripts** page (`/scripts`), or the public repo under `scripts/apb/` (<https://github.com/affbros/agencyplaybook-cli/tree/main/scripts/apb>). The `/scripts` page reads a live catalogue, so each card's description, cadence, and safety badge come straight from the script's own manifest header.

## Updating this skill

This skill tracks the CLI surface. When a new `apb` version ships, grab the latest bundle and re-extract it into `~/.claude/skills/`:

- **From the dashboard** — the **CLI Reference** page has a "Download Skill" button.
- **From GitHub** — <https://github.com/affbros/agencyplaybook-cli/tree/main/skills/agencyplaybook-cli>

Then restart Claude Code.
